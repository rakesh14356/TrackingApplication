﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TrackingApp
{
    public partial class NameList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindNames();
            }
        }

        private void BindNames()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ActivityTrackerDBConnection"].ConnectionString;
            string query = "SELECT DISTINCT Name FROM PersonActivity ORDER BY Name";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    GridViewNames.DataSource = dt;
                    GridViewNames.DataBind();
                }
            }
        }

        protected void GridViewNames_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewDetails")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string name = GridViewNames.DataKeys[index].Value.ToString();
                Response.Redirect($"PersonDetails.aspx?name={name}");
            }
        }
    }
}