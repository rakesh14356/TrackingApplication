﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace TrackingApp
{
    public partial class AddRecord : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["date"] != null)
                {
                    string selectedDate = Request.QueryString["date"];
                    lblDate.Text = "Selected Date: " + selectedDate;
                    calendarDate.SelectedDate = DateTime.Parse(selectedDate);
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string selectedDate = calendarDate.SelectedDate.ToShortDateString();
            string name = txtName.Text;
            string height = txtHeight.Text;
            string weight = txtWeight.Text;
            string gender = ddlGender.SelectedValue;
            bool gymActivity = chkGym.Checked;
            bool meditationActivity = chkMeditation.Checked;
            string meditationMinutes = txtMeditationMinutes.Text;
            bool readingActivity = chkReading.Checked;
            string readingPages = txtReadingPages.Text;
            string bmi = txtBMI.Text;
            string wakeUpTime = txtWakeUpTime.Text;

            // Save the record to the database
            string connectionString = ConfigurationManager.ConnectionStrings["ActivityTrackerDBConnection"].ConnectionString;
            string query = "INSERT INTO PersonActivity (Date, Name, Height, Weight, Gender, GymActivity, MeditationActivity, MeditationMinutes, ReadingActivity, ReadingPages, BMI, WakeUpTime) " +
                           "VALUES (@Date, @Name, @Height, @Weight, @Gender, @GymActivity, @MeditationActivity, @MeditationMinutes, @ReadingActivity, @ReadingPages, @BMI, @WakeUpTime)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Date", selectedDate);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Height", height);
                    cmd.Parameters.AddWithValue("@Weight", weight);
                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@GymActivity", gymActivity);
                    cmd.Parameters.AddWithValue("@MeditationActivity", meditationActivity);
                    cmd.Parameters.AddWithValue("@MeditationMinutes", meditationMinutes);
                    cmd.Parameters.AddWithValue("@ReadingActivity", readingActivity);
                    cmd.Parameters.AddWithValue("@ReadingPages", readingPages);
                    cmd.Parameters.AddWithValue("@BMI", bmi);
                    cmd.Parameters.AddWithValue("@WakeUpTime", wakeUpTime);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Record saved successfully
                        Response.Write("<script>alert('Record added successfully.');</script>");
                        // Clear the form for next entry
                        ClearForm();
                        // Redirect to PersonDetails.aspx with query parameters
                        Response.Redirect($"PersonDetails.aspx?date={selectedDate}&name={name}");
                    }
                    else
                    {
                        // Failed to save the record
                        Response.Write("<script>alert('Failed to save the record. Please try again.');</script>");
                    }
                }
            }
        }

        protected void calendarDate_SelectionChanged(object sender, EventArgs e)
        {
            lblDate.Text = "Selected Date: " + calendarDate.SelectedDate.ToShortDateString();
        }

        private void ClearForm()
        {
            txtName.Text = "";
            txtHeight.Text = "";
            txtWeight.Text = "";
            ddlGender.SelectedIndex = 0;
            chkGym.Checked = false;
            chkMeditation.Checked = false;
            txtMeditationMinutes.Text = "";
            chkReading.Checked = false;
            txtReadingPages.Text = "";
            txtBMI.Text = "";
            txtWakeUpTime.Text = "";
        }
    }
}