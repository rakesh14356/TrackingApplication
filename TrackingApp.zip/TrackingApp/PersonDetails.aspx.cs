﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace TrackingApp
{
    public partial class PersonDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["name"] != null)
                {
                    string name = Request.QueryString["name"];
                    LoadPersonDetails(name);
                }
            }
        }

        private void LoadPersonDetails(string name)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ActivityTrackerDBConnection"].ConnectionString;
            string query = "SELECT Date, Name, Height, Weight, Gender, GymActivity, MeditationActivity, MeditationMinutes, ReadingActivity, ReadingPages, BMI FROM PersonActivity WHERE Name=@Name ORDER BY Date DESC";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Build the data in a tabular form using StringBuilder
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    sb.Append("<tbody>");
                    int rowNumber = 1;
                    while (reader.Read())
                    {
                        sb.Append("<tr>");
                        sb.Append($"<td>{reader["Date"]}</td>");
                        sb.Append($"<td>{reader["Name"]}</td>");
                        sb.Append($"<td>{reader["Height"]}</td>");
                        sb.Append($"<td>{reader["Weight"]}</td>");
                        sb.Append($"<td>{reader["Gender"]}</td>");
                        sb.Append($"<td>{reader["GymActivity"]}</td>");
                        sb.Append($"<td>{reader["MeditationActivity"]}</td>");
                        sb.Append($"<td>{reader["MeditationMinutes"]}</td>");
                        sb.Append($"<td>{reader["ReadingActivity"]}</td>");
                        sb.Append($"<td>{reader["ReadingPages"]}</td>");
                        sb.Append($"<td>{reader["BMI"]}</td>");
                        sb.Append("</tr>");
                        rowNumber++;
                    }
                    sb.Append("</tbody>");

                    // Set the generated data to the Literal control
                    litPersonDetails.Text = sb.ToString();

                    // Display the name in the Label
                    if (rowNumber > 1)
                    {
                        lblName.Text = name;
                    }
                }
            }
        }

        protected void btnAddRecord_Click(object sender, EventArgs e)
        {
            // Redirect to the AddRecord page with the selected date as a query parameter
            string selectedDate = DateTime.Now.ToShortDateString();
            string name = Request.QueryString["name"];
            Response.Redirect($"AddRecord.aspx?name={name}&date={selectedDate}");
            

            // Your code to add a record (as shown in previous responses)

            // Display success message for added record
            lblMessage.Text = "Record added successfully!";


        }
       

private void DeleteRecord(string name, string selectedDate)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ActivityTrackerDBConnection"].ConnectionString;
            string query = "DELETE FROM PersonActivity WHERE Name=@Name AND Date=@Date";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Date", selectedDate);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                       
                        // Record deleted successfully
                        // You can add any success message here if needed
                    }
                    else
                    {
                        // Failed to delete the record
                        // You can add an error message here if needed
                    }
                }
            }
        }
        protected void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            string selectedDate = lblDate.Text;
            string name = Request.QueryString["name"];

            // Perform the delete operation based on the selected date and name
            DeleteRecord(name, selectedDate);
            lblMessage.Text = "Record deleted successfully!";


            // Redirect back to the PersonDetails page after deletion
            Response.Redirect($"PersonDetails.aspx?name={name}");

            
        }
    }
}